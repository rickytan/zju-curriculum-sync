<?php
include_once('../phpLinb/linb.php');
?>
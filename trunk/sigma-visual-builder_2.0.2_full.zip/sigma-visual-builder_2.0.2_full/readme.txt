1. Introduction
This is a SigmaVisual 2.0 version(internal v2.0.15) and allowed to use under LGPL or you have to buy commercial license for better support or other purpose usage. This builder is web based tool for AJAX RIA application UI rapid design and involved scripts programming. 
    * WYSIWYG GUI builder. Do everything by drag & drop.  Significant development time reduction.
    * More than 40 common components, including Tabs, Dialog, TreeGrid, TimeLine and many other web GUI components.
    * Rich client-side API, works with any backend (php, .Net, Java, python) or static HTML pages.
    * Wide cross-browser compatibility, IE6+, firefox1.5+, opera9+, safari3+ and Google Chrome.
    * Full API Documentation with tons of samples.
    * Ever Increasing Code Snippets.
    * Compatible with jQuery, prototype, mootools and other frameworks.
    * Dual Licenses - Commercial License and  LGPL license both available.  

2. System required
server: PHP5.0+ Apache2.0+
client: firefox1.5+ IE6+ opera9+ safari3+

3. How to install
Download the package and unzip to a directory.
Copy the whole directory to apache php-enabled directory.
Make sure the directory is writable.
Open index.html through browser.


4. Further Guide
To visit us, go to www.sigmawidgets.com
To download previous or latest version, go to www.sigmawidgets.com/download.html
To look for help or support, go to www.sigmawidgets.com/forum
To get more support or service, or any purchase issue, send email to sales@sigmawidgets.com

5. About Sigmasoft
Sigmasoft Technologies LLC is a software company providing cross-browser javascript GUI components and tools & services involved. Our aim is to make AJAX simple and easy. 
Sigmasoft also provides end-to-end solutions in web development (Web 2.0, PHP, ASP.NET, ASP, JSP, XML, Flash), application development and IT consulting services.
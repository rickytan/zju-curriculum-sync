Class('App.linb_UI_Stacks', 'linb.Com',{
    Instance:{
        //base Class for linb.Com
        base:["linb.UI"], 
        //requried  class for the App
        required:["linb.UI.Tabs", "linb.UI.Button", "linb.UI.Label", "linb.UI.ButtonViews", "linb.UI.Stacks", "linb.UI.Layout"], 

        iniComponents:function(){
            // [[code created by jsLinb UI Builder
            var host=this, children=[], append=function(child){children.push(child.get(0))};
            
            append((new linb.UI.Stacks)
                .host(host,"Stacks1")
                .setItems([{"id":"view1", "caption":"view1", "closeBtn":true, "landBtn":true, "optBtn":true}, {"id":"view2", "caption":"view2", "closeBtn":true, "optBtn":true}, {"id":"view3", "caption":"view3", "closeBtn":true, "optBtn":true}])
                .setLeft(0)
                .setTop(0)
                .setValue("view2")
                .afterPageClose("_stacks1_afterpageclose")
                .onShowOptions("_stacks1_onshowoptions")
                .onItemSelected("_stacks1_onitemselected")
            );
            
            host.Stacks1.append((new linb.UI.Button)
                .host(host,"Button1")
                .setLeft(240)
                .setTop(20)
                .setCaption("Button1")
            , 'view1');
            
            host.Stacks1.append((new linb.UI.Tabs)
                .host(host,"tabs6")
                .setItems([{"id":"a", "caption":"itema", "tips":"item a", "sub":[{"id":"aa", "caption":"suba"}, {"id":"ab", "caption":"subb"}]}, {"id":"b", "caption":"itemb", "tips":"item b"}, {"id":"c", "caption":"itemc", "tips":"item c"}])
                .setLeft(0)
                .setTop(0)
            , 'view2');
            
            host.tabs6.append((new linb.UI.Stacks)
                .host(host,"stacks3")
                .setItems([{"id":"a", "caption":"itema", "tips":"item a", "sub":[{"id":"aa", "caption":"suba"}, {"id":"ab", "caption":"subb"}]}, {"id":"b", "caption":"itemb", "tips":"item b"}, {"id":"c", "caption":"itemc", "tips":"item c"}])
                .setLeft(0)
                .setTop(0)
            , 'a');
            
            host.stacks3.append((new linb.UI.Tabs)
                .host(host,"tabs7")
                .setItems([{"id":"a", "caption":"itema", "tips":"item a", "sub":[{"id":"aa", "caption":"suba"}, {"id":"ab", "caption":"subb"}]}, {"id":"b", "caption":"itemb", "tips":"item b"}, {"id":"c", "caption":"itemc", "tips":"item c"}])
                .setLeft(0)
                .setTop(0)
            , 'a');
            
            return children;
            // ]]code created by jsLinb UI Builder
        }, 
        _stacks1_afterpageclose:function (profile, item) {
            linb.message('you just closed '+item.id);
        }, 
        _stacks1_onitemselected:function (profile, item, src) {
            linb.message('You just selected '+item.id)
        }, 
        _stacks1_onshowoptions:function (profile, item, e, src) {
            linb.message('onShowOptions : '+item.id)
        }
    }
});
/***********************************************
* AnyLink Drop Down Menu- ?Dynamic Drive (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit http://www.dynamicdrive.com/ for full source code
***********************************************/
var menuwidth='' //default menu width
var menubgcolor=''  //menu bgcolor
var disappeardelay=150  //menu disappear speed onMouseout (in miliseconds)
var hidemenu_onclick="yes" //hide menu when user clicks within menu?

var ie4=document.all
var ns6=document.getElementById&&!document.all

if (ie4||ns6)
document.write('<div id="dropmenudiv" style="z-index:100;visibility:hidden;wrap: no-wrap;width:'+menuwidth+';background-color:'+menubgcolor+'" onMouseover="clearhidemenu()" onMouseout="dynamichide(event)"></div>')

function getposOffset(what, offsettype){
var totaloffset=(offsettype=="left")? what.offsetLeft : what.offsetTop;
var parentEl=what.offsetParent;
while (parentEl!=null){
totaloffset=(offsettype=="left")? totaloffset+parentEl.offsetLeft : totaloffset+parentEl.offsetTop;
parentEl=parentEl.offsetParent;
}
return totaloffset;
}


function showhide(obj, e, visible, hidden, menuwidth){
if (ie4||ns6)
dropmenuobj.style.left=dropmenuobj.style.top=-500
if (menuwidth!=""){
dropmenuobj.widthobj=dropmenuobj.style
dropmenuobj.widthobj.width=menuwidth
}
if (e.type=="click" && obj.visibility==hidden || e.type=="mouseover")
obj.visibility=visible
else if (e.type=="click")
obj.visibility=hidden
}

function iecompattest(){
return (document.compatMode && document.compatMode!="BackCompat")? document.documentElement : document.body
}

function clearbrowseredge(obj, whichedge){
var edgeoffset=0
if (whichedge=="rightedge"){
var windowedge=ie4 && !window.opera? iecompattest().scrollLeft+iecompattest().clientWidth-15 : window.pageXOffset+window.innerWidth-15
dropmenuobj.contentmeasure=dropmenuobj.offsetWidth
if (windowedge-dropmenuobj.x < dropmenuobj.contentmeasure)
edgeoffset=dropmenuobj.contentmeasure-obj.offsetWidth
}
else{
var topedge=ie4 && !window.opera? iecompattest().scrollTop : window.pageYOffset
var windowedge=ie4 && !window.opera? iecompattest().scrollTop+iecompattest().clientHeight-15 : window.pageYOffset+window.innerHeight-18
dropmenuobj.contentmeasure=dropmenuobj.offsetHeight
if (windowedge-dropmenuobj.y < dropmenuobj.contentmeasure){ //move up?
edgeoffset=dropmenuobj.contentmeasure+obj.offsetHeight
if ((dropmenuobj.y-topedge)<dropmenuobj.contentmeasure) //up no good either?
edgeoffset=dropmenuobj.y+obj.offsetHeight-topedge
}
}
return edgeoffset
}

function populatemenu(what){
if (ie4||ns6)
dropmenuobj.innerHTML=what.join("")
}


function dropdownmenu(obj, e, menucontents, menuwidth){
	if (window.event) 
		event.cancelBubble=true
	else if (e.stopPropagation) e.stopPropagation()
		clearhidemenu()
	dropmenuobj=document.getElementById? document.getElementById("dropmenudiv") : dropmenudiv
	populatemenu(menucontents)

	if (ie4||ns6){
	showhide(dropmenuobj.style, e, "visible", "hidden", menuwidth)
	dropmenuobj.x=getposOffset(obj, "left")
	dropmenuobj.y=getposOffset(obj, "top")
	dropmenuobj.style.left=dropmenuobj.x-clearbrowseredge(obj, "rightedge")+"px"
	dropmenuobj.style.top=dropmenuobj.y-clearbrowseredge(obj, "bottomedge")+obj.offsetHeight+"px"
}

return clickreturnvalue()
}

function clickreturnvalue(){
if (ie4||ns6) return false
else return true
}

function contains_ns6(a, b) {
while (b.parentNode)
if ((b = b.parentNode) == a)
return true;
return false;
}

function dynamichide(e){
if (ie4&&!dropmenuobj.contains(e.toElement))
delayhidemenu()
else if (ns6&&e.currentTarget!= e.relatedTarget&& !contains_ns6(e.currentTarget, e.relatedTarget))
delayhidemenu()
}

function hidemenu(e)
{
	if (typeof dropmenuobj!="undefined")
	{
		if (ie4||ns6)
			dropmenuobj.style.visibility="hidden"
	}

	// Reset the company menu
	document.getElementById("menu1").className = "menuLink";

	// Reset the products menu
	document.getElementById("menu2").className = "menuLink";

	// Reset the resources menu
	document.getElementById("menu3").className = "menuLink";

	// Reset the resources menu
	//document.getElementById("menu4").className = "menuLink";

}

function delayhidemenu()
{
	if (ie4||ns6)
		delayhide=setTimeout("hidemenu()",disappeardelay)
}

function clearhidemenu(){
if (typeof delayhide!="undefined")
clearTimeout(delayhide)
}

if (hidemenu_onclick=="yes")
document.onclick=hidemenu

/* Modified by Mytch */

function ResetMenu(Not)
{
	for(i = 1; i <=3; i++)
	{
		if(i != Not)
			document.getElementById("menu" + i).className = "menuLink";
	}
}

var menuProducts = new Array();


menuProducts[0]='<a href="http://www.sigmawidgets.com/products/sigma_visual/sigmavisual.html" class="menuBlock"><font color=#ff8c00>Sigma Visual UI Builder</font></a>';
menuProducts[1]='<a href="http://www.sigmawidgets.com/products/sigma_visual/bin/index.html" class="menuBlock">Try Sigma Visual Online</a>';
menuProducts[2]='<a href="http://www.sigmawidgets.com/products/sigma_visual/sigmalinb.html" class="menuBlock"><font color=#ff8c00>Sigma Linb</font></a>';
menuProducts[3]='<a href="http://www.sigmawidgets.com/products/sigma_visual/sigmalinb.html" class="menuBlock">Sigma Linb Demo</a>';
menuProducts[4]='<a href="http://www.sigmawidgets.com/products/sigma_grid2/index.html" class="menuBlock"><font color=#ff8c00>Sigma Grid</font></a>';
menuProducts[5]='<a href="http://www.sigmawidgets.com/products/sigma_grid2/demos/index.html" class="menuBlock">Sigma Grid Demo</a>';


var menuServices = new Array();

menuServices[0]='<a href="http://www.sigmawidgets.com/company/customize.html" class="menuBlock">Web Components Customizations</a>';
menuServices[1]='<a href="http://www.sigmawidgets.com/company/offshore.html" class="menuBlock">OffShore Outsourcing</a>';
menuServices[2]='<a href="mailto:support@sigmawidgets.com" class="menuBlock">Email Support</a>';
menuServices[3]='<a href="http://www.sigmawidgets.com/forum/" class="menuBlock">Forum</a>';
menuServices[4]='<a href="http://www.sigmawidgets.com/company/about_us.html" class="menuBlock">About Us</a>';


var menuDemo = new Array();

menuDemo[0]='<a href="http://www.sigmawidgets.com/products/sigma_visual/bin/index.html" class="menuBlock">Try Sigma Visual Online</a>';
menuDemo[1]='<a href="http://www.sigmawidgets.com/products/sigma_visual/sigmalinb.html" class="menuBlock">Sigma Linb Demo List</a>';
menuDemo[2]='<a href="http://www.sigmawidgets.com/products/sigma_visual/bin/projects/OrderManagement/index.html" class="menuBlock">&nbsp;&nbsp;&nbsp;&nbsp;Portfolio-Order Managment</a>';
menuDemo[3]='<a href="http://www.sigmawidgets.com/products/sigma_visual/bin/projects/OutLook/index.html" class="menuBlock"><font color=#ff8c00>&nbsp;&nbsp;&nbsp;&nbsp;Portfolio-Personal Info Asistant</font></a>';
menuDemo[4]='<a href="http://www.sigmawidgets.com/products/sigma_grid2/demos/index.html" class="menuBlock">Sigma Grid Demo List</a>';




{
    info:'The next step is to get second.js',
    nexturi:'second.js'
}

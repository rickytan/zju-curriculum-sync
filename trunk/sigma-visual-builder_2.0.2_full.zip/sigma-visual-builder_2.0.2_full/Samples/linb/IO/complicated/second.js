{
    info:'The next step is to get third.js',
    nexturi1:'third.js',
    nexturi2:'fourth.js',
}

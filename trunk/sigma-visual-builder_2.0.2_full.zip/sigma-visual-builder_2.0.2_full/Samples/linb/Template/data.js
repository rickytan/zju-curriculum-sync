{
    head:"On sale products",
    items:[{
        id:"a",
        src:"img/g1_0.gif",
        href:"#",
        price:"$ 18.99",
        title:"product #0",
        desc:"product #0 is on sale now!"
    },{
        id:"b",
        src:"img/g1_1.jpg",
        href:"#",
        price:"$ 23.99",
        title:"product #1",
        desc:"product #1 is on sale now!"
    },{
        id:"c",
        src:"img/g1_2.jpg",
        href:"#",
        price:"$ 33.99",
        title:"product #2",
        desc:"product #2 is on sale now!"
    },{
        id:"d",
        src:"img/g1_3.jpg",
        href:"#",
        price:"$ 94.99",
        title:"product #3",
        desc:"product #3 is on sale now!"
    },{
        id:"e",
        src:"img/g1_4.jpg",
        href:"#",
        price:"$ 64.99",
        title:"product #4",
        desc:"product #4 is on sale now!"
    },{
        id:"f",
        src:"img/g1_5.jpg",
        href:"#",
        price:"$ 42.99",
        title:"product #5",
        desc:"product #5 is on sale now!"
    }]
}
_.merge(﻿linb.Locale.cn,{
    app:{
        caption:'标题',
        tips:'提示',
        message:'消息',
        
        list:{
            a:'条目一',
            b:'条目二',
            c:'条目三',
            d:'条目四'
        }
    }
});
_.merge(linb.Locale.en,{
    app:{
        caption:'caption',
        tips:'tips',
        message:'message',
        
        list:{
            a:'item a',
            b:'item b',
            c:'item c',
            d:'item d'
        }
    }
});
<?php
include_once("imglib/core/class.image.php5.php");
include_once('../../../phpLinb/linb.php');
?>
<?php
   define("IMAGEDEBUG","0");	 

   define("BASEURL","http://localhost:8080/jsLinb2.0/Samples/comb/PicEditor//imglib");
   define("BASEPATH","E:\\sigmawidgets.com\\jsLinb2.0\\Samples\\comb\picEditor\\imglib");
   
   define("IMAGEBASEURL", BASEURL . "/working");
   define("IMAGEBASEPATH",BASEPATH . DIRECTORY_SEPARATOR . "working");
	 
   define("MODERNPATH", BASEPATH . DIRECTORY_SEPARATOR . "template" . DIRECTORY_SEPARATOR . "modern");
   define("AVATARPATH", BASEPATH . DIRECTORY_SEPARATOR . "template" . DIRECTORY_SEPARATOR . "avatar");


   define("IMAGEFONTDIR", BASEPATH . DIRECTORY_SEPARATOR . "font");
	 
   define("IMAGEINTERLACE","1");
   define("IMAGEJPEGQUALITY","80");	
?>
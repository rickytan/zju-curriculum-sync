CONF={
    //Dynamic Injector Mechanism for linb.ComFactory
    ComFactoryProfile:{
        //_iniMethod:'create',
        event:{
            cls:'App.event'
        }
    }
};
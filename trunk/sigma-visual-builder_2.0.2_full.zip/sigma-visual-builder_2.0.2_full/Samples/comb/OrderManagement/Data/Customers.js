 [{
    "company_name" : "Inspringsoft",
    "first_name" : "Steven",
    "last_name" : "Du",
    "email" : "sales@sigmawidgets.com",
    "web_site" : "www.sigmawidgets.com",
    "phone_number" : "1234567890",
    "fax_number" : "1234567890",
    "bill_address" : "No.3 abcd Road, XX state, US",
    "shipment_address" : "No.3 abcd Road, XX state, US"   
},{
    "company_name" : "Sigmasoft",
    "first_name" : "Chris",
    "last_name" : "Zhou",
    "email" : "support@sigmawidgets.com",
    "web_site" : "www.sigmawidgets.com",
    "phone_number" : "0987654321",
    "fax_number" : "0987654321",
	"bill_address" : "No.5 efg block, hijk state, CA",
	"shipment_address" : "No.5 efg block, hijk state, CA"   
},{
    "company_name" : "STE",
    "first_name" : "Renny",
    "last_name" : "Kim",
    "email" : "renny@sigmawidgets.com",
    "web_site" : "www.sigmawidgets.com",
    "phone_number" : "6789012345",
    "fax_number" : "6789012345",
	"bill_address" : "2345 Brick Road",
	"shipment_address" : "2345 Brick Road"   
},{
    "company_name" : "Sopysoft",
    "first_name" : "Ruby",
    "last_name" : "Yan",
    "email" : "ruby@sigmawidgets.com",
    "web_site" : "www.sigmawidgets.com",
    "phone_number" : "8901234567",
    "fax_number" : "8901234567",
	"bill_address" : "somewhere",
	"shipment_address" : "somewhere"   
}]